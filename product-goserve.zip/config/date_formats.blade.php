<?php
return [
    [
        "format"=> "Y-m-d H:i",
    ],
    [
        "format"=> "Y-m-d h:i a",
    ],
    [
        "format"=> "F j, Y, g:i a",
    ],
]
?>