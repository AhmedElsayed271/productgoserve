<?php

namespace App\Repositories\dashboard;

use App\Models\User;
use Illuminate\Support\Facades\Hash;

class usersRepository
{
    
}