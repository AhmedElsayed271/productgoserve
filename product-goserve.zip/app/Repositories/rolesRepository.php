<?php

namespace App\Repositories\dashboard;

use App\Models\Role;
use Illuminate\Support\Facades\Hash;

class rolesRepository
{
    
}